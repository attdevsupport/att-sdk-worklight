
/* JavaScript content from js/textToSpeech.js in folder common */
var params={},invocationData={},options={};

/**
 * Function to send the request for speechToText Conversion
 * @param textString - text to convert to an audio file
 * @param language - language of the text
 * @param voice - person's voice you want to speak the text
 * @param callback - Callback function after successful invocation of the method
 */

textToSpeech = function(textString, language, voice, callback)
{
	var params = 
	{
		"accessToken" : "Bearer " + window.localStorage.accessToken,
		"contentType" : "text/plain",
		"accept" : "audio/amr-wb",
		"contentLanguage" : language,
		"xArg": "VoiceName=" + voice,
		"contentLength" : textString.length,
		"body" : textString
	};
	
	var invocationData = 
	{
        adapter : 'TextToSpeech',
        procedure : 'textToSpeech',
        parameters : [params]
    };
	
	options = 
	{
		onSuccess : function (result)
		{
			busyInd.hide();	
			callback(result);
		},
		onFailure : function (result)
		{
			busyInd.hide();	
			callback(result);
		},
		invocationContext : {}
	};
	WL.Client.invokeProcedure(invocationData, options);
};

playSpeech = function(speechResult)
{
	 WL.Logger.debug("TTS Result: " + JSON.stringify(result));	
};